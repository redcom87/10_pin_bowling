# Bowling-score
American 10-pin Bowling score counting script

To run project just open `index.html` in a browser. Lates version.

To start unit test run these comands in a terminal from project folder:
```
> npm install
> npm test
```